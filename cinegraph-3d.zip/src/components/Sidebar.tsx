import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Film, User, Tag, Star, Calendar, Bookmark, BookmarkCheck, CheckCircle2 } from 'lucide-react';
import { Node } from '../data/dummyData';
import { mockApi, WatchlistEntry } from '../services/mockApi';

interface SidebarProps {
  node: Node | null;
  onClose: () => void;
  watchlist: WatchlistEntry[];
  onUpdateWatchlist: () => void;
}

export default function Sidebar({ node, onClose, watchlist, onUpdateWatchlist }: SidebarProps) {
  const [isEditingWatchlist, setIsEditingWatchlist] = useState(false);
  const [notes, setNotes] = useState('');
  const [priority, setPriority] = useState(5);
  const [rating, setRating] = useState<number | ''>('');

  const watchlistEntry = node ? watchlist.find(w => w.film_id === node.id) : null;
  const isInWatchlist = !!watchlistEntry;

  useEffect(() => {
    if (watchlistEntry) {
      setNotes(watchlistEntry.notes || '');
      setPriority(watchlistEntry.priority || 5);
      setRating(watchlistEntry.rating || '');
    } else {
      setNotes('');
      setPriority(5);
      setRating('');
    }
    setIsEditingWatchlist(false);
  }, [node, watchlistEntry]);

  const handleSaveWatchlist = async () => {
    if (!node) return;
    
    if (rating !== '') {
      await mockApi.rateFilm(node.id, Number(rating), notes, priority);
    } else {
      await mockApi.addToWatchlist(node.id, notes, priority);
    }
    
    onUpdateWatchlist();
    setIsEditingWatchlist(false);
  };

  const handleRemoveWatchlist = async () => {
    if (!node) return;
    await mockApi.removeFromWatchlist(node.id);
    onUpdateWatchlist();
    setIsEditingWatchlist(false);
  };

  return (
    <AnimatePresence>
      {node && (
        <motion.div
          initial={{ x: '100%', opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: '100%', opacity: 0 }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="fixed right-0 top-0 bottom-0 w-80 md:w-96 bg-[#1a1a1a]/95 backdrop-blur-xl border-l border-white/5 p-6 z-50 text-white overflow-y-auto shadow-2xl"
        >
          <button
            onClick={onClose}
            className="absolute top-6 right-6 p-2 rounded-full hover:bg-white/10 transition-colors"
          >
            <X size={20} />
          </button>

          <div className="mt-8">
            <div className="flex items-center gap-3 mb-2">
              {node.type === 'Movie' && <Film className="text-rose-500" size={24} />}
              {node.type === 'Person' && <User className="text-blue-500" size={24} />}
              {node.type === 'Genre' && <Tag className="text-emerald-500" size={24} />}
              <span className="text-sm font-mono tracking-wider uppercase text-white/50">
                {node.type}
              </span>
            </div>
            
            <h2 className="text-3xl font-bold font-serif mb-6 leading-tight text-white/90">
              {node.name}
            </h2>

            {node.type === 'Movie' && (
              <>
                <div className="flex gap-4 mb-6">
                  {node.year && (
                    <div className="flex items-center gap-2 text-white/70">
                      <Calendar size={16} />
                      <span>{node.year}</span>
                    </div>
                  )}
                  {node.rating && (
                    <div className="flex items-center gap-2 text-yellow-500">
                      <Star size={16} className="fill-current" />
                      <span>{node.rating}</span>
                    </div>
                  )}
                </div>

                {/* Watchlist Section */}
                <div className="mb-8 bg-white/5 border border-white/10 rounded-xl p-4">
                  {!isEditingWatchlist ? (
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {isInWatchlist ? (
                            watchlistEntry?.watched ? <CheckCircle2 size={18} className="text-emerald-500" /> : <BookmarkCheck size={18} className="text-[#d4a359]" />
                          ) : (
                            <Bookmark size={18} className="text-white/50" />
                          )}
                          <span className="font-semibold text-sm">
                            {isInWatchlist 
                              ? (watchlistEntry?.watched ? 'Watched' : 'In Watchlist') 
                              : 'Not in Watchlist'}
                          </span>
                        </div>
                        <button 
                          onClick={() => setIsEditingWatchlist(true)}
                          className="text-xs bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded transition-colors"
                        >
                          {isInWatchlist ? 'Edit' : 'Add'}
                        </button>
                      </div>
                      
                      {isInWatchlist && (
                        <div className="mt-3 space-y-2 text-sm text-white/70">
                          {watchlistEntry?.rating && (
                            <div className="flex items-center gap-2">
                              <span className="text-white/40 w-16">My Rating:</span>
                              <span className="text-yellow-500 flex items-center gap-1">
                                <Star size={12} className="fill-current" /> {watchlistEntry.rating}/10
                              </span>
                            </div>
                          )}
                          <div className="flex items-center gap-2">
                            <span className="text-white/40 w-16">Priority:</span>
                            <span>{watchlistEntry?.priority}/10</span>
                          </div>
                          {watchlistEntry?.notes && (
                            <div className="flex gap-2">
                              <span className="text-white/40 w-16">Notes:</span>
                              <span className="italic">"{watchlistEntry.notes}"</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div>
                        <label className="text-xs text-white/50 mb-1 block">Priority (1-10)</label>
                        <input 
                          type="number" min="1" max="10" 
                          value={priority} onChange={e => setPriority(Number(e.target.value))}
                          className="w-full bg-[#1a1a1a] border border-white/10 rounded px-3 py-2 text-sm focus:outline-none focus:border-[#d4a359]"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-white/50 mb-1 block">My Rating (1-10, optional)</label>
                        <input 
                          type="number" min="1" max="10" 
                          value={rating} onChange={e => setRating(e.target.value ? Number(e.target.value) : '')}
                          placeholder="Leave empty if not watched"
                          className="w-full bg-[#1a1a1a] border border-white/10 rounded px-3 py-2 text-sm focus:outline-none focus:border-[#d4a359]"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-white/50 mb-1 block">Notes</label>
                        <textarea 
                          value={notes} onChange={e => setNotes(e.target.value)}
                          className="w-full bg-[#1a1a1a] border border-white/10 rounded px-3 py-2 text-sm focus:outline-none focus:border-[#d4a359] min-h-[80px]"
                        />
                      </div>
                      <div className="flex gap-2 pt-2">
                        <button 
                          onClick={handleSaveWatchlist}
                          className="flex-1 bg-[#d4a359] hover:bg-[#e5b46a] text-black font-medium py-2 rounded text-sm transition-colors"
                        >
                          Save
                        </button>
                        {isInWatchlist && (
                          <button 
                            onClick={handleRemoveWatchlist}
                            className="flex-1 bg-red-500/20 hover:bg-red-500/30 text-red-400 font-medium py-2 rounded text-sm transition-colors border border-red-500/30"
                          >
                            Remove
                          </button>
                        )}
                        <button 
                          onClick={() => setIsEditingWatchlist(false)}
                          className="flex-1 bg-white/10 hover:bg-white/20 py-2 rounded text-sm transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}

            {node.description && (
              <div className="mb-8">
                <h3 className="text-sm font-mono uppercase tracking-widest text-white/40 mb-3">
                  About
                </h3>
                <p className="text-white/70 leading-relaxed text-sm">
                  {node.description}
                </p>
              </div>
            )}

            <div className="mt-auto pt-8 border-t border-white/5">
              <h3 className="text-sm font-mono uppercase tracking-widest text-white/40 mb-4">
                Graph Stats
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                  <div className="text-2xl font-light mb-1 text-white/90">{node.val.toFixed(1)}</div>
                  <div className="text-xs text-white/40 uppercase tracking-wider">Influence</div>
                </div>
                <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                  <div className="text-2xl font-light mb-1 text-white/90">{node.id}</div>
                  <div className="text-xs text-white/40 uppercase tracking-wider">Node ID</div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
