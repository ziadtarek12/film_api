import React, { useRef, useEffect, useState, useMemo, useCallback } from 'react';
import ForceGraph2D from 'react-force-graph-2d';
import { GraphData, Node, Link } from '../data/dummyData';
import { FilterGroup } from '../App';

interface GraphViewProps {
  data: GraphData;
  onNodeClick: (node: Node) => void;
  selectedNodeId: string | null;
  forces: {
    centerForce: number;
    repelForce: number;
    linkForce: number;
    linkDistance: number;
  };
  display: {
    showLabels: boolean;
    nodeSize: 'influence' | 'rating';
    linkThickness: number;
  };
  groups: FilterGroup[];
}

export default function GraphView({ data, onNodeClick, selectedNodeId, forces, display, groups }: GraphViewProps) {
  const fgRef = useRef<any>();
  const [dimensions, setDimensions] = useState({ width: window.innerWidth, height: window.innerHeight });
  const [hoverNode, setHoverNode] = useState<Node | null>(null);

  useEffect(() => {
    const handleResize = () => {
      setDimensions({ width: window.innerWidth, height: window.innerHeight });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Apply forces
  useEffect(() => {
    if (fgRef.current) {
      fgRef.current.d3Force('charge').strength(-forces.repelForce);
      fgRef.current.d3Force('link').distance(forces.linkDistance);
      
      const centerForce = fgRef.current.d3Force('center');
      if (centerForce && typeof centerForce.strength === 'function') {
        centerForce.strength(forces.centerForce);
      }
      
      fgRef.current.d3ReheatSimulation();
    }
  }, [forces]);

  // Focus on selected node
  useEffect(() => {
    if (selectedNodeId && fgRef.current) {
      const node = data.nodes.find(n => n.id === selectedNodeId);
      if (node) {
        fgRef.current.centerAt(node.x, node.y, 1000);
        fgRef.current.zoom(4, 1000);
      }
    }
  }, [selectedNodeId, data.nodes]);

  // Pre-calculate neighbors for fast lookup
  const neighbors = useMemo(() => {
    const map = new Map<string, Set<string>>();
    data.nodes.forEach(n => map.set(n.id, new Set()));
    data.links.forEach(l => {
      const sourceId = typeof l.source === 'object' ? (l.source as any).id : l.source;
      const targetId = typeof l.target === 'object' ? (l.target as any).id : l.target;
      map.get(sourceId)?.add(targetId);
      map.get(targetId)?.add(sourceId);
    });
    return map;
  }, [data]);

  const highlightNodes = useMemo(() => {
    const set = new Set<string>();
    if (hoverNode) {
      set.add(hoverNode.id);
      neighbors.get(hoverNode.id)?.forEach(id => set.add(id));
    }
    if (selectedNodeId) {
      set.add(selectedNodeId);
      neighbors.get(selectedNodeId)?.forEach(id => set.add(id));
    }
    return set;
  }, [hoverNode, selectedNodeId, neighbors]);

  const highlightLinks = useMemo(() => {
    const set = new Set<any>();
    if (hoverNode || selectedNodeId) {
      data.links.forEach(l => {
        const sourceId = typeof l.source === 'object' ? (l.source as any).id : l.source;
        const targetId = typeof l.target === 'object' ? (l.target as any).id : l.target;
        if (
          (hoverNode && (sourceId === hoverNode.id || targetId === hoverNode.id)) ||
          (selectedNodeId && (sourceId === selectedNodeId || targetId === selectedNodeId))
        ) {
          set.add(l);
        }
      });
    }
    return set;
  }, [hoverNode, selectedNodeId, data.links]);

  const getNodeRadius = useCallback((node: Node) => {
    if (display.nodeSize === 'rating' && node.type === 'Movie') {
      return Math.max(1, (node.rating || 5) / 2);
    }
    return Math.sqrt(node.val || 1) * 1.5;
  }, [display.nodeSize]);

  const getNodeColor = useCallback((node: Node) => {
    for (const g of groups) {
      if (!g.query) continue;
      const query = g.query.toLowerCase();
      if (query.startsWith('type:')) {
        if (node.type.toLowerCase() === query.substring(5).trim()) return g.color;
      } else {
        if (node.name.toLowerCase().includes(query)) return g.color;
      }
    }
    return '#9ca3af'; // default gray
  }, [groups]);

  const paintNode = useCallback((node: any, ctx: CanvasRenderingContext2D, globalScale: number) => {
    const isSelected = selectedNodeId === node.id;
    const isHovered = hoverNode?.id === node.id;
    const isHighlighted = highlightNodes.has(node.id);
    const isDimmed = (hoverNode || selectedNodeId) && !isHighlighted;

    const color = getNodeColor(node);
    const radius = getNodeRadius(node);

    ctx.beginPath();
    ctx.arc(node.x, node.y, radius, 0, 2 * Math.PI, false);
    
    // Fill
    ctx.fillStyle = isDimmed ? `${color}20` : color;
    ctx.fill();

    // Border for selected/hovered
    if (isSelected || isHovered) {
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1 / globalScale;
      ctx.stroke();
    }

    // Text
    const showText = display.showLabels || isHighlighted || globalScale > 2.5;
    if (showText && !isDimmed) {
      const fontSize = isHighlighted ? 12 / globalScale : 8 / globalScale;
      ctx.font = `${fontSize}px Inter, sans-serif`;
      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.fillText(node.name, node.x, node.y + radius + 2 / globalScale);
    }
  }, [selectedNodeId, hoverNode, highlightNodes, display.showLabels, getNodeRadius, getNodeColor]);

  return (
    <div className="absolute inset-0 bg-[#000000] overflow-hidden">
      <ForceGraph2D
        ref={fgRef}
        graphData={data}
        width={dimensions.width}
        height={dimensions.height}
        nodeLabel={() => ''} // Disable default tooltip
        nodeCanvasObject={paintNode}
        nodePointerAreaPaint={(node: any, color, ctx) => {
          const radius = getNodeRadius(node);
          ctx.fillStyle = color;
          ctx.beginPath();
          ctx.arc(node.x, node.y, radius + 4, 0, 2 * Math.PI, false); // Add padding for easier clicking
          ctx.fill();
        }}
        linkColor={(link: any) => highlightLinks.has(link) ? 'rgba(255,255,255,0.6)' : 'rgba(255,255,255,0.1)'}
        linkWidth={(link: any) => highlightLinks.has(link) ? display.linkThickness * 2 : display.linkThickness}
        linkDirectionalArrowLength={0}
        onNodeClick={onNodeClick}
        onNodeHover={(node: any) => {
          document.body.style.cursor = node ? 'pointer' : 'default';
          setHoverNode(node || null);
        }}
        backgroundColor="#000000"
        d3VelocityDecay={0.1} // Slower decay for more Obsidian-like settling animation
        d3AlphaDecay={0.01} // Slower alpha decay for longer animation
      />
    </div>
  );
}
