import { Node, dummyData } from '../data/dummyData';

export interface WatchlistEntry {
  id: string;
  film_id: string;
  notes: string;
  priority: number;
  watched: boolean;
  rating?: number;
  film: Node;
}

let watchlist: WatchlistEntry[] = [];

// Mocking the API endpoints described in the README
export const mockApi = {
  login: async () => {
    return { access_token: 'mock_jwt_token', user: { name: 'John Doe' } };
  },
  
  getWatchlist: async (): Promise<WatchlistEntry[]> => {
    return [...watchlist].sort((a, b) => b.priority - a.priority);
  },
  
  addToWatchlist: async (film_id: string, notes: string, priority: number) => {
    const film = dummyData.nodes.find(n => n.id === film_id);
    if (!film) throw new Error('Film not found');
    
    const existing = watchlist.find(w => w.film_id === film_id);
    if (existing) {
      existing.notes = notes;
      existing.priority = priority;
      return existing;
    }

    const entry: WatchlistEntry = { 
      id: Date.now().toString(), 
      film_id, 
      notes, 
      priority, 
      watched: false, 
      film 
    };
    watchlist.push(entry);
    return entry;
  },
  
  rateFilm: async (film_id: string, rating: number, notes: string, priority: number) => {
    let entry = watchlist.find(w => w.film_id === film_id);
    if (!entry) {
      entry = await mockApi.addToWatchlist(film_id, notes, priority);
    }
    entry.rating = rating;
    entry.watched = true;
    entry.notes = notes;
    entry.priority = priority;
    return entry;
  },

  removeFromWatchlist: async (film_id: string) => {
    watchlist = watchlist.filter(w => w.film_id !== film_id);
  },
  
  getRecommendations: async (): Promise<Node[]> => {
    // Simulating the 6-factor recommendation engine by returning highly rated movies
    // that share genres/directors with the user's highly rated watchlist items.
    // For dummy purposes, we just return a random highly-rated subset.
    const movies = dummyData.nodes.filter(n => n.type === 'Movie' && n.rating && n.rating > 8.0);
    return movies.sort(() => 0.5 - Math.random()).slice(0, 10);
  }
};
