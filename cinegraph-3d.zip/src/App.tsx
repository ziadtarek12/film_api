import React, { useState, useMemo, useEffect } from 'react';
import GraphView from './components/GraphView';
import Sidebar from './components/Sidebar';
import SearchBar from './components/SearchBar';
import ControlsPanel from './components/ControlsPanel';
import { dummyData, Node } from './data/dummyData';
import { mockApi, WatchlistEntry } from './services/mockApi';
import { motion, AnimatePresence } from 'motion/react';
import { Bookmark, Sparkles } from 'lucide-react';

export interface FilterGroup {
  id: string;
  query: string;
  color: string;
  hidden?: boolean;
}

export default function App() {
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [watchlist, setWatchlist] = useState<WatchlistEntry[]>([]);
  const [recommendations, setRecommendations] = useState<Node[]>([]);
  const [graphMode, setGraphMode] = useState<'all' | 'watchlist' | 'recommendations'>('all');
  
  const [forces, setForces] = useState({
    centerForce: 0.5,
    repelForce: 100,
    linkForce: 0.5,
    linkDistance: 30,
  });

  const [filters, setFilters] = useState({
    title: '',
    genres: '',
    actors: '',
    directors: '',
  });

  const [display, setDisplay] = useState({
    showLabels: false,
    nodeSize: 'influence' as const,
    linkThickness: 0.5,
  });

  const [groups, setGroups] = useState<FilterGroup[]>([
    { id: '1', query: 'type:Movie', color: '#9333ea', hidden: false },
    { id: '2', query: 'type:Person', color: '#0ea5e9', hidden: false },
    { id: '3', query: 'type:Genre', color: '#10b981', hidden: false },
  ]);

  useEffect(() => {
    mockApi.getWatchlist().then(setWatchlist);
    mockApi.getRecommendations().then(setRecommendations);
  }, []);

  const handleNodeClick = (node: Node) => {
    setSelectedNode(node);
  };

  const handleCloseSidebar = () => {
    setSelectedNode(null);
  };

  const handleUpdateWatchlist = async () => {
    const updated = await mockApi.getWatchlist();
    setWatchlist(updated);
  };

  // Filter logic
  const filteredData = useMemo(() => {
    let baseMovies = dummyData.nodes.filter(n => n.type === 'Movie');

    // Apply graph mode (Watchlist / For You)
    if (graphMode === 'watchlist') {
      const watchlistIds = new Set(watchlist.map(w => w.film_id));
      baseMovies = baseMovies.filter(m => watchlistIds.has(m.id));
    } else if (graphMode === 'recommendations') {
      const recIds = new Set(recommendations.map(r => r.id));
      baseMovies = baseMovies.filter(m => recIds.has(m.id));
    }

    const titleQ = filters.title.toLowerCase();
    const genresQ = filters.genres.toLowerCase().split(',').map(s => s.trim()).filter(Boolean);
    const actorsQ = filters.actors.toLowerCase().split(',').map(s => s.trim()).filter(Boolean);
    const directorsQ = filters.directors.toLowerCase().split(',').map(s => s.trim()).filter(Boolean);

    // Find movies that match the text criteria
    const matchingMovies = new Set<string>();

    baseMovies.forEach(node => {
      let matches = true;
      if (titleQ && !node.name.toLowerCase().includes(titleQ)) matches = false;

      // Get connected nodes for this movie
      const connectedNodes = dummyData.links
        .filter(l => {
          const sourceId = typeof l.source === 'object' ? (l.source as any).id : l.source;
          const targetId = typeof l.target === 'object' ? (l.target as any).id : l.target;
          return sourceId === node.id || targetId === node.id;
        })
        .map(l => {
          const sourceId = typeof l.source === 'object' ? (l.source as any).id : l.source;
          const targetId = typeof l.target === 'object' ? (l.target as any).id : l.target;
          const otherId = sourceId === node.id ? targetId : sourceId;
          return dummyData.nodes.find(n => n.id === otherId);
        })
        .filter(Boolean) as Node[];

      if (genresQ.length > 0) {
        const movieGenres = connectedNodes.filter(n => n.type === 'Genre').map(n => n.name.toLowerCase());
        if (!genresQ.some(g => movieGenres.some(mg => mg.includes(g)))) matches = false;
      }

      if (actorsQ.length > 0) {
        const movieActors = connectedNodes.filter(n => n.type === 'Person').map(n => n.name.toLowerCase());
        if (!actorsQ.some(a => movieActors.some(ma => ma.includes(a)))) matches = false;
      }

      if (directorsQ.length > 0) {
        const movieDirectors = connectedNodes.filter(n => n.type === 'Person').map(n => n.name.toLowerCase());
        if (!directorsQ.some(d => movieDirectors.some(md => md.includes(d)))) matches = false;
      }

      if (matches) {
        matchingMovies.add(node.id);
      }
    });

    // Now build the graph with only matching movies and their immediate connections
    const newNodes = new Set<Node>();
    const newLinks = dummyData.links.filter(l => {
      const sourceId = typeof l.source === 'object' ? (l.source as any).id : l.source;
      const targetId = typeof l.target === 'object' ? (l.target as any).id : l.target;
      
      if (matchingMovies.has(sourceId) || matchingMovies.has(targetId)) {
        const sourceNode = dummyData.nodes.find(n => n.id === sourceId);
        const targetNode = dummyData.nodes.find(n => n.id === targetId);
        if (sourceNode) newNodes.add(sourceNode);
        if (targetNode) newNodes.add(targetNode);
        return true;
      }
      return false;
    });

    // Apply group visibility filtering
    const hiddenGroups = groups.filter(g => g.hidden && g.query);
    const isNodeHidden = (node: Node) => {
      for (const g of hiddenGroups) {
        if (!g.query) continue;
        const query = g.query.toLowerCase();
        if (query.startsWith('type:')) {
          if (node.type.toLowerCase() === query.substring(5).trim()) return true;
        } else {
          if (node.name.toLowerCase().includes(query)) return true;
        }
      }
      return false;
    };

    const finalNodes = Array.from(newNodes).filter(n => !isNodeHidden(n));
    const finalNodeIds = new Set(finalNodes.map(n => n.id));
    const finalLinks = newLinks.filter(l => {
      const sourceId = typeof l.source === 'object' ? (l.source as any).id : l.source;
      const targetId = typeof l.target === 'object' ? (l.target as any).id : l.target;
      return finalNodeIds.has(sourceId) && finalNodeIds.has(targetId);
    });

    return {
      nodes: finalNodes,
      links: finalLinks
    };
  }, [filters, graphMode, watchlist, recommendations, groups]);

  return (
    <div className="relative w-full h-screen bg-[#000000] overflow-hidden font-sans text-white">
      {/* Main 2D Graph */}
      <GraphView 
        data={filteredData} 
        onNodeClick={handleNodeClick} 
        selectedNodeId={selectedNode?.id || null}
        forces={forces}
        display={display}
        groups={groups}
      />

      {/* UI Overlay */}
      <div className="absolute inset-0 pointer-events-none z-20">
        
        {/* Top Navigation Bar */}
        <div className="absolute top-6 left-6 flex items-center gap-4 pointer-events-auto z-50">
          <SearchBar nodes={filteredData.nodes} onSelect={handleNodeClick} />
          
          <button 
            onClick={() => setGraphMode(p => p === 'watchlist' ? 'all' : 'watchlist')}
            className={`flex items-center gap-2 px-4 py-3 rounded-full border transition-all shadow-xl ${
              graphMode === 'watchlist' 
                ? 'bg-[#d4a359] text-black border-[#d4a359]' 
                : 'bg-[#1a1a1a]/80 backdrop-blur-md border-white/10 text-white/80 hover:bg-white/10'
            }`}
          >
            <Bookmark size={18} />
            <span className="text-sm font-medium">Watchlist</span>
          </button>
          
          <button 
            onClick={() => setGraphMode(p => p === 'recommendations' ? 'all' : 'recommendations')}
            className={`flex items-center gap-2 px-4 py-3 rounded-full border transition-all shadow-xl ${
              graphMode === 'recommendations' 
                ? 'bg-[#d4a359] text-black border-[#d4a359]' 
                : 'bg-[#1a1a1a]/80 backdrop-blur-md border-white/10 text-white/80 hover:bg-white/10'
            }`}
          >
            <Sparkles size={18} />
            <span className="text-sm font-medium">For You</span>
          </button>
        </div>

        {/* Branding */}
        <div className="absolute bottom-8 left-8 pointer-events-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-full bg-white/5 backdrop-blur-md flex items-center justify-center border border-white/10">
              <span className="font-serif italic text-xl text-white/80">C</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-white/90">CineGraph</h1>
              <p className="text-xs font-mono uppercase tracking-[0.2em] text-white/40">
                Obsidian-style Graph
              </p>
            </div>
          </motion.div>
        </div>

        {/* Controls Panel */}
        <div className="pointer-events-auto">
          <ControlsPanel 
            forces={forces} setForces={setForces} 
            filters={filters} setFilters={setFilters}
            display={display} setDisplay={setDisplay}
            groups={groups} setGroups={setGroups}
          />
        </div>
      </div>

      {/* Sidebar Panel */}
      <div className="pointer-events-auto z-50 relative">
        <Sidebar 
          node={selectedNode} 
          onClose={handleCloseSidebar} 
          watchlist={watchlist}
          onUpdateWatchlist={handleUpdateWatchlist}
        />
      </div>
    </div>
  );
}
