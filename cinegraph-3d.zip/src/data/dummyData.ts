export type NodeType = 'Movie' | 'Person' | 'Genre';

export interface Node {
  id: string;
  name: string;
  type: NodeType;
  val: number; // Size in graph
  color?: string;
  image?: string;
  description?: string;
  year?: number;
  rating?: number;
  runtime?: string;
  certificate?: string;
  x?: number;
  y?: number;
  z?: number;
}

export interface Link {
  source: string;
  target: string;
  label: string;
}

export interface GraphData {
  nodes: Node[];
  links: Link[];
}

const generateDummyData = (): GraphData => {
  const nodes: Node[] = [];
  const links: Link[] = [];

  // 15 Genres
  const genres = ['Action', 'Adventure', 'Sci-Fi', 'Drama', 'Comedy', 'Thriller', 'Horror', 'Romance', 'Mystery', 'Crime', 'Animation', 'Fantasy', 'Documentary', 'Family', 'Music'];
  genres.forEach((g, i) => {
    nodes.push({ id: `g${i}`, name: g, type: 'Genre', val: 8 });
  });

  // 150 People (Actors/Directors)
  for (let i = 0; i < 150; i++) {
    nodes.push({ id: `p${i}`, name: `Person ${i}`, type: 'Person', val: Math.random() * 3 + 1 });
  }

  // 500 Movies
  for (let i = 0; i < 500; i++) {
    nodes.push({ 
      id: `m${i}`, 
      name: `Movie ${i}`, 
      type: 'Movie', 
      val: Math.random() * 2 + 0.5,
      year: 1980 + Math.floor(Math.random() * 44),
      rating: 5 + Math.random() * 5,
      runtime: `${90 + Math.floor(Math.random() * 60)} mins`,
      certificate: ['PG-13', 'R', 'PG', 'G'][Math.floor(Math.random() * 4)],
      description: `A generated description for Movie ${i}. This would normally contain the plot summary from the API.`
    });

    // Link to 1-3 genres
    const numGenres = 1 + Math.floor(Math.random() * 3);
    for (let j = 0; j < numGenres; j++) {
      links.push({ source: `m${i}`, target: `g${Math.floor(Math.random() * genres.length)}`, label: 'IN_GENRE' });
    }

    // Link to 1 director
    links.push({ source: `p${Math.floor(Math.random() * 150)}`, target: `m${i}`, label: 'DIRECTED' });

    // Link to 2-5 actors
    const numActors = 2 + Math.floor(Math.random() * 4);
    for (let j = 0; j < numActors; j++) {
      links.push({ source: `p${Math.floor(Math.random() * 150)}`, target: `m${i}`, label: 'ACTED_IN' });
    }
  }

  return { nodes, links };
};

export const dummyData = generateDummyData();
